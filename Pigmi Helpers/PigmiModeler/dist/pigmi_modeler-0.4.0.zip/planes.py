"""Stable construction frames derived from the geometry at the stroke start."""
import bmesh
from mathutils import Vector
from .geometry import plane_basis


def edge_direction(cursor, edge):
    return cursor.obj.matrix_world.to_3x3() @ (edge.verts[1].co-edge.verts[0].co)


def face_frame(cursor, face, preferred=None):
    normal=(cursor.obj.matrix_world.to_3x3().inverted().transposed() @ face.normal).normalized()
    edges=[e for e in face.edges if not e.hide]
    edge=preferred if preferred in edges else max(edges,key=lambda e:edge_direction(cursor,e).length_squared,default=None)
    tangent=edge_direction(cursor,edge) if edge is not None else None
    return normal,plane_basis(normal,tangent)[0]


def auto_frame(cursor, target=None):
    view_normal=cursor.rv3d.view_rotation @ Vector((0,0,1))
    view_right=cursor.rv3d.view_rotation @ Vector((1,0,0))
    origin=cursor.start_point(target)
    origin=origin if origin is not None else cursor.plane_origin.copy()
    if isinstance(target,bmesh.types.BMFace):
        normal,u=face_frame(cursor,target)
        return origin,normal,u,'Auto: face / longest edge'
    if isinstance(target,(bmesh.types.BMEdge,bmesh.types.BMVert)):
        faces=[f for f in target.link_faces if not f.hide]
        if faces:
            def score(face):
                n=(cursor.obj.matrix_world.to_3x3().inverted().transposed() @ face.normal).normalized()
                return abs(n.dot(view_normal))
            face=max(faces,key=score)
            normal,u=face_frame(cursor,face,target if isinstance(target,bmesh.types.BMEdge) else None)
            return origin,normal,u,'Auto: adjacent face / edge'
        edges=[target] if isinstance(target,bmesh.types.BMEdge) else [e for e in target.link_edges if not e.hide]
        edges.sort(key=lambda e:edge_direction(cursor,e).length_squared,reverse=True)
        if edges:
            u=edge_direction(cursor,edges[0]).normalized()
            if len(edges)>1:
                cross=max((u.cross(edge_direction(cursor,e).normalized()) for e in edges[1:]),key=lambda n:n.length_squared)
                if cross.length>.01:
                    normal=cross.normalized()
                    if normal.dot(view_normal)<0:
                        normal.negate()
                    return origin,normal,u,'Auto: connected edges'
            normal=view_normal-u*view_normal.dot(u)
            if normal.length<1e-5:
                normal=plane_basis(u)[0]
            return origin,normal.normalized(),u,'Auto: edge + view'
    if cursor.settings.has_anchor:
        normal=Vector(cursor.settings.last_normal)
        u=plane_basis(normal,Vector(cursor.settings.last_tangent))[0]
        return origin,normal,u,'Auto: previous drawing plane'
    return origin,view_normal,view_right,'Auto: view'


def update_auto(cursor,target=None):
    if cursor.settings.locked:
        return
    cursor.plane_origin,cursor.plane_normal,cursor.plane_u,cursor.plane_label=auto_frame(cursor,target)
