bl_info = {'name': 'Pigmi Modeler', 'author': 'Pigmi', 'version': (0, 2, 1),
           'blender': (4, 2, 0), 'category': 'Mesh',
           'description': 'Direct low-poly modeling with a unified cursor',
           'location': 'Edit Mode > Toolbar > Pigmi'}

import time
import bpy
import bmesh
import blf
import gpu
from bpy.props import BoolProperty, FloatProperty, FloatVectorProperty, IntProperty, PointerProperty, EnumProperty
from bpy_extras import view3d_utils as view
from mathutils import Vector
from .cursor import Cursor, CYAN, GOLD, SHADERS
from .geometry import plane_basis, ray_plane, grid_snap, create_face, polygon_error, match_edge_endpoints, project_plane

ACTIVE = None
HOVERS = {}
HANDLERS = []


def active_tool(context):
    if context.mode != 'EDIT_MESH' or not context.area or context.area.type != 'VIEW_3D':
        return False
    tool = context.workspace.tools.from_space_view3d_mode('EDIT_MESH', create=False)
    return tool and tool.idname == 'pigmi.modeler'


def supported(context):
    return (context.mode == 'EDIT_MESH' and len(context.objects_in_mode) == 1
            and not context.edit_object.data.shape_keys
            and abs(context.edit_object.matrix_world.determinant()) > 1e-10)


class PigmiSettings(bpy.types.PropertyGroup):
    snap: BoolProperty(name='Snap to vertices', default=True)
    grid: BoolProperty(name='Grid', default=False)
    step: FloatProperty(name='Step', default=.25, min=.001, subtype='DISTANCE')
    radius: IntProperty(name='Pick radius', default=12, min=4, max=40)
    locked: BoolProperty(default=False)
    last_point: FloatVectorProperty(size=3)
    has_anchor: BoolProperty(default=False)
    origin: FloatVectorProperty(size=3)
    normal: FloatVectorProperty(size=3, default=(0,0,1))
    show_plane: BoolProperty(name='Show plane', default=True)
    hold: FloatProperty(name='Hold to extrude', default=.35, min=.2, max=1)


class PIGMI_OT_blank(bpy.types.Operator):
    bl_idname = 'pigmi.blank'
    bl_label = 'New Pigmi Mesh'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        mesh = bpy.data.meshes.new('Pigmi Mesh')
        obj = bpy.data.objects.new('Pigmi', mesh)
        context.collection.objects.link(obj)
        for other in context.selected_objects:
            other.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj
        obj.location = context.scene.cursor.location
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.wm.tool_set_by_id(name='pigmi.modeler')
        return {'FINISHED'}


class PIGMI_OT_activate(bpy.types.Operator):
    bl_idname = 'pigmi.activate'
    bl_label = 'Use Pigmi Tool'

    @classmethod
    def poll(cls, context):
        return context.mode == 'EDIT_MESH'

    def execute(self, context):
        context.space_data.show_gizmo = True
        bpy.ops.wm.tool_set_by_id(name='pigmi.modeler')
        return {'FINISHED'}


class PIGMI_OT_plane(bpy.types.Operator):
    bl_idname = 'pigmi.plane'
    bl_label = 'Pigmi Construction Plane'
    bl_options = {'REGISTER', 'UNDO'}
    mode: EnumProperty(items=[(s,s,'') for s in ('FACE','VIEW','FREE','UP','DOWN')], default='VIEW')

    def invoke(self, context, event):
        if not supported(context):
            return {'CANCELLED'}
        if ACTIVE:
            return {'CANCELLED'}
        cursor = Cursor(context, event)
        message = change_plane(cursor, self.mode)
        if message:
            self.report({'INFO'}, message)
            return {'CANCELLED'}
        HOVERS[context.region.as_pointer()] = cursor
        context.area.tag_redraw()
        return {'FINISHED'}


def change_plane(cursor, mode):
    settings = cursor.settings
    if mode == 'FACE':
        hit = cursor.face_hit()
        if not hit:
            return 'Hover a face and press P'
        face, point = hit
        normal = (cursor.obj.matrix_world.to_3x3().inverted().transposed() @ face.normal).normalized()
        origin = point
    elif mode == 'VIEW':
        origin = cursor.start_point(cursor.pick())
        if origin is None:
            origin = cursor.plane_origin.copy()
        normal = cursor.rv3d.view_rotation @ Vector((0,0,1))
    elif mode == 'FREE':
        settings.locked = False
        cursor.plane_normal = cursor.rv3d.view_rotation @ Vector((0,0,1))
        return None
    else:
        normal = cursor.plane_normal.copy()
        origin = cursor.plane_origin + normal * settings.step * (1 if mode == 'UP' else -1)
    settings.origin, settings.normal, settings.locked = origin, normal, True
    cursor.plane_origin, cursor.plane_normal = origin.copy(), normal.copy()
    return None


def native_face_extrude(context, cursor, target):
    # Delegate to the same Blender operator used by Extrude Along Normals.
    faces = [f for f in cursor.bm.faces if f.select and not f.hide] if target.select else [target]
    for sequence in (cursor.bm.faces, cursor.bm.edges, cursor.bm.verts):
        for element in sequence:
            element.select = False
    cursor.bm.select_history.clear()
    for face in faces:
        face.select_set(True)
    cursor.bm.faces.active = target
    bmesh.update_edit_mesh(cursor.obj.data, loop_triangles=False, destructive=False)
    HOVERS.clear()
    bpy.ops.view3d.edit_mesh_extrude_move_normal('INVOKE_REGION_WIN')


class PIGMI_OT_face_extrude(bpy.types.Operator):
    bl_idname = 'pigmi.face_extrude'
    bl_label = 'Pigmi: Blender Face Extrude'

    def invoke(self, context, event):
        if not supported(context) or ACTIVE:
            return {'CANCELLED'}
        cursor = Cursor(context,event)
        hit = cursor.face_hit()
        selected = [f for f in cursor.bm.faces if f.select and not f.hide]
        target = hit[0] if hit else selected[0] if selected else None
        if target is None:
            self.report({'INFO'}, 'Hover or select a face to extrude')
            return {'CANCELLED'}
        native_face_extrude(context,cursor,target)
        return {'FINISHED'}


class PIGMI_OT_gesture(bpy.types.Operator):
    bl_idname = 'pigmi.gesture'
    bl_label = 'Pigmi Gesture'
    bl_options = {'REGISTER', 'UNDO', 'BLOCKING'}
    intent: EnumProperty(items=[(s,s,'') for s in ('AUTO','MOVE','EXTRUDE','DELETE','DRAW')], default='AUTO')

    def invoke(self, context, event):
        global ACTIVE
        if ACTIVE or not supported(context):
            self.report({'INFO'}, 'Pigmi needs one mesh without shape keys in Edit Mode')
            return {'CANCELLED'}
        context.tool_settings.mesh_select_mode = (True, True, True)
        self.c = Cursor(context, event)
        self.c.bm.select_mode = {'VERT', 'EDGE', 'FACE'}
        self.selection_before = {v for v in self.c.bm.verts if v.select}
        self.target = self.c.pick()
        self.c.hover = self.target
        self.state = 'PRESS'
        self.press = self.c.mouse.copy()
        self.pressed_at = time.monotonic()
        self.shift = event.shift
        self.points, self.refs = [], []
        self.preview = None
        self.note = ''
        self.original = {}
        self.delta = Vector()
        self.end_on_release = True
        self.timer = None
        if self.intent == 'DELETE':
            if self.target is not None:
                if isinstance(self.target, bmesh.types.BMEdge) and self.target.is_manifold:
                    bmesh.ops.dissolve_edges(self.c.bm, edges=[self.target], use_verts=False)
                elif isinstance(self.target, bmesh.types.BMVert) and len(self.target.link_edges) == 2:
                    bmesh.ops.dissolve_verts(self.c.bm, verts=[self.target], use_face_split=False)
                else:
                    kind = 'VERTS' if isinstance(self.target,bmesh.types.BMVert) else 'EDGES' if isinstance(self.target,bmesh.types.BMEdge) else 'FACES_ONLY'
                    bmesh.ops.delete(self.c.bm, geom=[self.target], context=kind)
                self.flush()
                return {'FINISHED'}
            return {'CANCELLED'}
        start = self.c.start_point(self.target)
        if start is not None and (not self.c.settings.locked or isinstance(self.target,bmesh.types.BMVert)):
            self.c.plane_origin = start.copy()
        ACTIVE = self
        self.timer = context.window_manager.event_timer_add(.05, window=context.window)
        context.window_manager.modal_handler_add(self)
        context.area.tag_redraw()
        if self.intent == 'DRAW':
            self.state = self.c.action = 'DRAW'
            return self.add_corner(context)
        return {'RUNNING_MODAL'}

    def flush(self):
        self.c.bm.normal_update()
        bmesh.update_edit_mesh(self.c.obj.data, loop_triangles=True, destructive=True)
        HOVERS.clear()

    def finish(self, context, cancel=False):
        global ACTIVE
        if cancel and self.original and self.c.bm.is_valid:
            for vertex, co in self.original.items():
                if vertex.is_valid:
                    vertex.co = co
            self.flush()
        if cancel and self.c.bm.is_valid:
            self.c.select_vertices(v for v in self.selection_before if v.is_valid)
        if self.timer is not None:
            context.window_manager.event_timer_remove(self.timer)
            self.timer = None
        ACTIVE = None
        HOVERS.clear()
        if self.c.area:
            self.c.area.tag_redraw()
        return {'CANCELLED' if cancel else 'FINISHED'}

    def cancel(self, context):
        self.finish(context, True)

    def begin_move(self):
        c = self.c
        if not self.target.select:
            c.select(self.target)
        c.moving = [v for v in c.bm.verts if v.select and not v.hide]
        self.original = {v:v.co.copy() for v in c.moving}
        mouse = c.mouse.copy()
        c.mouse = self.press.copy()
        self.center = c.start_point(self.target)
        c.mouse = mouse
        if self.center is None:
            return False
        self.normal = c.plane_normal
        self.anchor = ray_plane(*c.ray(self.press), self.center, self.normal)
        if self.anchor is None:
            self.note = 'Plane is edge-on. Orbit or press V after this gesture.'
            return False
        self.state = c.action = 'MOVE'
        return True

    def begin_extrude(self, release=True):
        c = self.c
        if not isinstance(self.target,bmesh.types.BMEdge):
            return False
        if isinstance(self.target,bmesh.types.BMEdge) and len(self.target.link_faces)>1:
            self.note = 'Extrude a boundary edge or face'
            return False
        self.source = c.element_points(self.target)
        mouse = c.mouse.copy()
        c.mouse = self.press.copy()
        self.center = c.start_point(self.target)
        c.mouse = mouse
        if self.center is None:
            return False
        self.normal = c.plane_normal
        self.anchor = ray_plane(*c.ray(self.press), self.center, self.normal)
        if self.anchor is None:
            return False
        self.state = c.action = 'EXTRUDE'
        self.end_on_release = release
        return True

    def update_motion(self):
        c = self.c
        if self.state == 'DRAW':
            self.preview = c.point_on_plane()
        elif self.state == 'MOVE':
            point = c.point_on_plane(self.center, self.normal, False)
            if point is None:
                return
            delta = point - self.anchor
            c.snap_ref = None
            # Snap the actual moved anchor, not the initial grab offset.
            candidate = self.center + delta
            best = c.settings.radius
            if c.settings.snap:
                screen = view.location_3d_to_region_2d(c.region,c.rv3d,candidate)
                if screen is not None:
                    for v in c.bm.verts:
                        if v.hide or v in c.moving:
                            continue
                        pos = c.obj.matrix_world @ v.co
                        xy = view.location_3d_to_region_2d(c.region,c.rv3d,pos)
                        if xy is not None and (xy-screen).length < best and c.visible(pos):
                            best = (xy-screen).length
                            candidate, c.snap_ref = pos, v
            if c.snap_ref is None and c.settings.grid:
                candidate = grid_snap(candidate,self.center,self.normal,c.settings.step)
            self.delta = candidate-self.center
            local = c.obj.matrix_world.inverted().to_3x3() @ self.delta
            for v, original in self.original.items():
                v.co = original + local
            bmesh.update_edit_mesh(c.obj.data,loop_triangles=True,destructive=False)
        elif self.state == 'EXTRUDE':
            point = c.point_on_plane(self.center,self.normal,False)
            if point is not None:
                self.delta = point-self.anchor
                if c.settings.grid:
                    self.delta = grid_snap(self.center+self.delta,self.center,self.normal,c.settings.step)-self.center
            self.edge_preview=[p+self.delta for p in self.source]
            self.edge_refs=[None,None]
            if c.settings.snap:
                self.snap_edge()

    def snap_edge(self):
        c=self.c
        projected=[view.location_3d_to_region_2d(c.region,c.rv3d,p) for p in self.edge_preview]
        if any(p is None for p in projected):
            return
        source_verts=set(self.target.verts)
        best=c.settings.radius*2
        for edge in c.bm.edges:
            if edge.hide or edge==self.target or len(edge.link_faces)>1 or source_verts.intersection(edge.verts):
                continue
            pts=[c.obj.matrix_world @ v.co for v in edge.verts]
            xy=[view.location_3d_to_region_2d(c.region,c.rv3d,p) for p in pts]
            if any(p is None for p in xy) or not all(c.visible(p) for p in pts):
                continue
            refs=match_edge_endpoints(projected,xy,list(edge.verts))
            locations=[c.obj.matrix_world @ v.co for v in refs]
            distances=[(a-view.location_3d_to_region_2d(c.region,c.rv3d,b)).length for a,b in zip(projected,locations)]
            if max(distances)<c.settings.radius and sum(distances)<best:
                candidate=[self.source[0],self.source[1],locations[1],locations[0]]
                normal=(candidate[1]-candidate[0]).cross(candidate[-1]-candidate[0])
                if normal.length>1e-8 and polygon_error(candidate,normal.normalized()) is None:
                    best=sum(distances)
                    self.edge_preview,self.edge_refs=locations,list(refs)

        if self.edge_refs == [None,None]:
            for i, screen in enumerate(projected):
                ref = c.vertex_snap(screen, exclude=source_verts | {v for v in self.edge_refs if v is not None})
                if ref is not None:
                    self.edge_refs[i] = ref
                    self.edge_preview[i] = c.obj.matrix_world @ ref.co

    def commit(self, context):
        c = self.c
        try:
            if self.state == 'DRAW':
                face = create_face(c.bm,self.points,self.refs,c.obj.matrix_world,c.plane_normal)
                c.select(face)
            elif self.state == 'EXTRUDE':
                if isinstance(self.target,bmesh.types.BMEdge):
                    moved=getattr(self,'edge_preview',[p+self.delta for p in self.source])
                    refs=getattr(self,'edge_refs',[None,None])
                    pts=[self.source[0],self.source[1],moved[1],moved[0]]
                    normal=(pts[1]-pts[0]).cross(pts[-1]-pts[0])
                    if normal.length < 1e-8:
                        raise ValueError('Drag away from the edge to grow a face')
                    face = create_face(c.bm,pts,[*self.target.verts,refs[1],refs[0]],c.obj.matrix_world,normal.normalized())
                    c.select(face)
            elif self.state == 'MOVE' and c.snap_ref is not None and len(c.moving)==1:
                bmesh.ops.pointmerge(c.bm,verts=[c.moving[0],c.snap_ref],merge_co=c.snap_ref.co.copy())
            if self.state == 'DRAW' and self.points:
                c.settings.last_point = self.points[-1]
                c.settings.has_anchor = True
            elif self.state in {'MOVE','EXTRUDE'}:
                c.settings.last_point = self.center + self.delta
                c.settings.has_anchor = True
            self.original = {}
            self.flush()
            return self.finish(context)
        except ValueError as error:
            self.note = str(error)
            return {'RUNNING_MODAL'}

    def add_corner(self, context):
        c = self.c
        point = c.point_on_plane()
        if point is None:
            self.note = 'Plane is edge-on. Orbit the view.'
            return {'RUNNING_MODAL'}
        if self.points:
            xy = view.location_3d_to_region_2d(c.region,c.rv3d,self.points[0])
            if len(self.points)>=3 and xy is not None and (xy-c.mouse).length < c.settings.radius:
                return self.commit(context)
            if (point-self.points[-1]).length < 1e-6:
                return {'RUNNING_MODAL'}
        if not self.points:
            c.plane_origin = point.copy()
        self.points.append(point.copy())
        self.refs.append(c.snap_ref)
        if len(self.points)==4:
            result = self.commit(context)
            if 'RUNNING_MODAL' in result:
                self.points.pop(); self.refs.pop()
            return result
        self.note = 'Click corners. Quad closes at 4; triangle: click first corner.'
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        try:
            return self.handle(context,event)
        except Exception as error:
            self.report({'ERROR'}, 'Pigmi: '+str(error))
            return self.finish(context,True)

    def handle(self, context, event):
        c = self.c
        if context.mode!='EDIT_MESH' or context.edit_object!=c.obj or not c.bm.is_valid:
            return self.finish(context,True)
        c.area.tag_redraw()
        if event.type in {'ESC','RIGHTMOUSE'} and event.value=='PRESS':
            return self.finish(context,True)
        if event.type in {'MIDDLEMOUSE','WHEELUPMOUSE','WHEELDOWNMOUSE','TRACKPADPAN','TRACKPADZOOM'}:
            return {'PASS_THROUGH'} if self.state=='DRAW' else {'RUNNING_MODAL'}
        if event.type == 'TIMER':
            return {'RUNNING_MODAL'}
        c.mouse = Vector((event.mouse_x-c.region.x,event.mouse_y-c.region.y))
        if event.value == 'PRESS' and event.type in {'P','V','UP_ARROW','DOWN_ARROW'}:
            if self.state not in {'PRESS','DRAW'}:
                self.note = 'Finish this drag before changing the plane'
                return {'RUNNING_MODAL'}
            mode = 'FACE' if event.type=='P' else ('FREE' if event.shift else 'VIEW') if event.type=='V' else 'UP' if event.type=='UP_ARROW' else 'DOWN'
            message = change_plane(c,mode)
            if message:
                self.note = message
            else:
                self.points = [p if ref is not None else project_plane(p,c.plane_origin,c.plane_normal) for p,ref in zip(self.points,self.refs)]
                self.note = 'Plane: face under cursor' if mode=='FACE' else 'Construction plane updated'
                self.update_motion()
            return {'RUNNING_MODAL'}
        if event.type=='MOUSEMOVE':
            if self.state=='PRESS' and (c.mouse-self.press).length>4:
                held = time.monotonic()-self.pressed_at >= c.settings.hold
                if self.target is None:
                    self.state=c.action='DRAW'
                    saved=c.mouse.copy(); c.mouse=self.press
                    self.add_corner(context); c.mouse=saved
                elif self.intent=='EXTRUDE' or (held and isinstance(self.target,(bmesh.types.BMEdge,bmesh.types.BMFace)) and self.intent!='MOVE') or (isinstance(self.target,bmesh.types.BMEdge) and self.target.is_boundary and self.intent!='MOVE'):
                    if isinstance(self.target,bmesh.types.BMFace):
                        self.finish(context)
                        native_face_extrude(context,c,self.target)
                        # The native operator owns the geometry and undo entry.
                        return {'CANCELLED'}
                    if not self.begin_extrude():
                        return self.finish(context,True)
                elif not self.begin_move():
                    return self.finish(context,True)
            self.update_motion()
        if event.type=='LEFTMOUSE' and event.value=='RELEASE':
            if self.state=='PRESS':
                if self.target is None and not self.shift:
                    self.state=c.action='DRAW'
                    return self.add_corner(context)
                if self.target is None:
                    c.select_vertices([])
                    return self.finish(context)
                if self.shift:
                    c.select(self.target,True)
                    return self.finish(context)
                c.select(self.target)
                return self.finish(context)
            if self.state=='MOVE' or self.state=='EXTRUDE' and self.end_on_release:
                return self.commit(context)
        if event.value=='PRESS':
            if event.type=='LEFTMOUSE' and self.state=='DRAW':
                return self.add_corner(context)
            if event.type=='LEFTMOUSE' and self.state=='EXTRUDE' and not self.end_on_release:
                return self.commit(context)
            if event.type in {'RET','NUMPAD_ENTER','SPACE'} and self.state in {'DRAW','EXTRUDE'}:
                return self.commit(context)
            if event.type=='BACK_SPACE' and self.state=='DRAW' and self.points:
                self.points.pop(); self.refs.pop()
            if event.type=='S':
                c.settings.snap=not c.settings.snap
            if event.type=='G':
                c.settings.grid=not c.settings.grid
        return {'RUNNING_MODAL'}


class PIGMI_GT_hover(bpy.types.Gizmo):
    bl_idname = 'PIGMI_GT_hover'

    def setup(self):
        self.use_draw_modal = True

    def draw(self, context):
        pass

    def test_select(self, context, location):
        if ACTIVE or not supported(context):
            return -1
        cursor = Cursor(context)
        cursor.mouse = Vector(location)
        cursor.hover = cursor.pick()
        HOVERS[context.region.as_pointer()] = cursor
        context.area.tag_redraw()
        return -1


class PIGMI_GGT_hover(bpy.types.GizmoGroup):
    bl_idname = 'PIGMI_GGT_hover'
    bl_label = 'Pigmi Hover'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_options = {'3D'}

    @classmethod
    def poll(cls, context):
        return active_tool(context) and supported(context)

    def setup(self, context):
        self.gizmos.new('PIGMI_GT_hover')


class PIGMI_WST_modeler(bpy.types.WorkSpaceTool):
    bl_idname = 'pigmi.modeler'
    bl_label = 'Pigmi'
    bl_description = 'Click to select, double click to build, drag to shape, drag boundary to grow. Shift: move, Ctrl: extrude, Alt: dissolve'
    bl_space_type = 'VIEW_3D'
    bl_context_mode = 'EDIT_MESH'
    bl_icon = 'ops.mesh.polybuild_hover'
    bl_widget = 'PIGMI_GGT_hover'
    bl_keymap = (
        ('pigmi.gesture', {'type':'LEFTMOUSE','value':'PRESS'}, {'properties':[('intent','AUTO')]}),
        ('pigmi.gesture', {'type':'LEFTMOUSE','value':'PRESS','shift':True}, {'properties':[('intent','MOVE')]}),
        ('pigmi.gesture', {'type':'LEFTMOUSE','value':'PRESS','ctrl':True}, {'properties':[('intent','EXTRUDE')]}),
        ('pigmi.gesture', {'type':'LEFTMOUSE','value':'PRESS','alt':True}, {'properties':[('intent','DELETE')]}),
        ('pigmi.gesture', {'type':'LEFTMOUSE','value':'DOUBLE_CLICK'}, {'properties':[('intent','DRAW')]}),
        ('pigmi.face_extrude', {'type':'E','value':'PRESS'}, {}),
        ('pigmi.gesture', {'type':'F','value':'PRESS'}, {'properties':[('intent','DRAW')]}),
        ('pigmi.plane', {'type':'P','value':'PRESS'}, {'properties':[('mode','FACE')]}),
        ('pigmi.plane', {'type':'V','value':'PRESS'}, {'properties':[('mode','VIEW')]}),
        ('pigmi.plane', {'type':'V','value':'PRESS','shift':True}, {'properties':[('mode','FREE')]}),
        ('pigmi.plane', {'type':'UP_ARROW','value':'PRESS'}, {'properties':[('mode','UP')]}),
        ('pigmi.plane', {'type':'DOWN_ARROW','value':'PRESS'}, {'properties':[('mode','DOWN')]}),
    )

    @staticmethod
    def draw_settings(context, layout, tool):
        settings=context.scene.pigmi_settings
        layout.prop(settings,'snap',text='Snap')
        layout.prop(settings,'grid')
        layout.prop(settings,'step')
        layout.label(text='Plane: '+('Locked' if settings.locked else 'View'))


class PIGMI_PT_panel(bpy.types.Panel):
    bl_label = 'Pigmi Modeler'
    bl_idname = 'PIGMI_PT_panel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Pigmi'

    def draw(self,context):
        layout=self.layout
        layout.operator('pigmi.blank',icon='MESH_DATA')
        layout.operator('pigmi.activate',icon='EDITMODE_HLT')
        settings=context.scene.pigmi_settings
        layout.prop(settings,'snap')
        layout.prop(settings,'grid')
        layout.prop(settings,'step')
        layout.prop(settings,'show_plane')
        layout.prop(settings,'hold')
        layout.separator()
        for line in ('Click: select | double click: build','Drag: move / grow boundary','Shift drag: move any element','E / hold drag face: Blender extrude','Alt click: dissolve / delete','P: face plane | V: view plane','Up / Down: plane offset','Shift V: release plane'):
            layout.label(text=line)


def overlay_cursor():
    context=bpy.context
    if not active_tool(context) or not context.region or context.region.type!='WINDOW' or not supported(context):
        return None
    if ACTIVE:
        c=ACTIVE.c
        return c if context.region==c.region else None
    c=HOVERS.get(context.region.as_pointer())
    if c is None or c.obj!=context.edit_object or not c.bm.is_valid:
        return None
    # Plane can be changed by a keyboard operator without moving the mouse.
    settings=c.settings
    if settings.locked:
        c.plane_origin = Vector(settings.origin)
    else:
        start = c.start_point(c.hover) if c.hover is not None and c.hover.is_valid else None
        c.plane_origin = start if start is not None else Vector(settings.last_point) if settings.has_anchor else context.scene.cursor.location.copy()
    c.plane_normal=Vector(settings.normal) if settings.locked else c.rv3d.view_rotation @ Vector((0,0,1))
    return c


def draw_world():
    c=overlay_cursor()
    if c is None:
        return
    c.shaders()
    gpu.state.blend_set('ALPHA')
    gpu.state.depth_mask_set(False)
    try:
        gpu.state.depth_test_set('LESS_EQUAL')
        if c.settings.show_plane:
            u,v=plane_basis(c.plane_normal)
            step=c.settings.step
            lines=[]
            for i in range(-5,6):
                for a,b in ((u,v),(v,u)):
                    lines += [c.plane_origin+a*i*step-b*5*step,c.plane_origin+a*i*step+b*5*step]
            c.lines(lines,(.12,.65,.8,.15),1)
        gpu.state.depth_test_set('NONE')
        if ACTIVE:
            op=ACTIVE
            if op.state=='DRAW':
                pts=op.points+([op.preview] if op.preview is not None and (not op.points or (op.preview-op.points[-1]).length>1e-5) else [])
                if len(op.points)>=3:
                    first = view.location_3d_to_region_2d(c.region,c.rv3d,op.points[0])
                    if first is not None and (first-c.mouse).length < c.settings.radius:
                        pts = list(op.points)
                error=polygon_error(pts,c.plane_normal) if len(pts)>=3 else None
                c.polygon(pts,(1,.25,.2,1) if error else CYAN,not error)
                for p in op.points:
                    marker(c,p,CYAN)
            elif op.state=='EXTRUDE':
                moved=getattr(op,'edge_preview',None) if len(op.source)==2 else None
                moved=moved if moved is not None else [p+op.delta for p in op.source]
                c.polygon(moved)
                count=len(op.source) if len(op.source)>2 else 1
                for i in range(count):
                    j=(i+1)%len(op.source)
                    c.polygon([op.source[i],op.source[j],moved[j],moved[i]])
            elif op.state=='MOVE':
                c.polygon(c.element_points(op.target),GOLD)
        if c.hover is not None and c.hover.is_valid and (not ACTIVE or ACTIVE.state=='PRESS'):
            points=c.element_points(c.hover)
            if len(points)==1:
                marker(c,points[0],GOLD)
            else:
                c.polygon(points,GOLD)
        if c.snap_ref is not None and c.snap_ref.is_valid:
            marker(c,c.obj.matrix_world @ c.snap_ref.co,(.4,1,.3,1))
    finally:
        gpu.state.depth_mask_set(True)
        gpu.state.depth_test_set('NONE')
        gpu.state.blend_set('NONE')


def marker(c, point, color):
    xy=view.location_3d_to_region_2d(c.region,c.rv3d,point)
    if xy is None:
        return
    scale=(view.region_2d_to_location_3d(c.region,c.rv3d,xy+Vector((5,0)),point)-point).length
    u=c.rv3d.view_rotation @ Vector((scale,0,0))
    v=c.rv3d.view_rotation @ Vector((0,scale,0))
    c.lines([point-u-v,point+u-v,point+u-v,point+u+v,point+u+v,point-u+v,point-u+v,point-u-v],color,2)


def draw_hud():
    c=overlay_cursor()
    if c is None:
        return
    if ACTIVE:
        op=ACTIVE
        if op.state=='PRESS' and op.target is not None:
            progress=min(1,(time.monotonic()-op.pressed_at)/c.settings.hold)
            hint='Hold to extrude ' + str(round(progress*100))+'%'
        elif op.state=='DRAW':
            hint=op.note or 'Click corners | 4 = quad | click first = triangle | Esc = cancel'
        else:
            hint=op.note or ('Release to confirm | Esc = cancel' if op.end_on_release else 'Click to confirm | Esc = cancel')
        title=op.state
    else:
        kind='VERTEX' if isinstance(c.hover,bmesh.types.BMVert) else 'EDGE' if isinstance(c.hover,bmesh.types.BMEdge) else 'FACE' if c.hover is not None else 'BUILD'
        title=kind
        hint={'VERTEX':'Click: select   Double click: build   Drag: move / weld', 'EDGE':'Click: select   Drag boundary: grow   Shift drag: move', 'FACE':'Drag: move   E / hold drag: Blender extrude   P: face plane', 'BUILD':'Click to start a quad   P: face plane   V: view plane'}[kind]
    rows=['PIGMI   /   '+title+'   /   '+('LOCKED PLANE' if c.settings.locked else 'VIEW PLANE'),hint]
    for i,row in enumerate(rows):
        blf.size(0,14 if i==0 else 12)
        blf.position(0,65,65-i*22,0)
        blf.color(0,*(CYAN if i==0 else (.92,.95,1,1)))
        blf.draw(0,row)


CLASSES=(PigmiSettings,PIGMI_OT_blank,PIGMI_OT_activate,PIGMI_OT_plane,PIGMI_OT_face_extrude,PIGMI_OT_gesture,PIGMI_GT_hover,PIGMI_GGT_hover,PIGMI_PT_panel)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.pigmi_settings=PointerProperty(type=PigmiSettings)
    bpy.utils.register_tool(PIGMI_WST_modeler,after={'builtin.poly_build'},separator=True,group=False)
    if not bpy.app.background:
        HANDLERS.extend((bpy.types.SpaceView3D.draw_handler_add(draw_world,(),'WINDOW','POST_VIEW'),bpy.types.SpaceView3D.draw_handler_add(draw_hud,(),'WINDOW','POST_PIXEL')))


def unregister():
    if ACTIVE:
        ACTIVE.cancel(bpy.context)
    for handle in HANDLERS:
        bpy.types.SpaceView3D.draw_handler_remove(handle,'WINDOW')
    HANDLERS.clear()
    HOVERS.clear()
    SHADERS.clear()
    bpy.utils.unregister_tool(PIGMI_WST_modeler)
    del bpy.types.Scene.pigmi_settings
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
