bl_info = {
    'name': 'Pigmi Modeler', 'author': 'Pigmi', 'version': (0, 1, 0),
    'blender': (4, 2, 0), 'location': 'View3D > Sidebar > Pigmi',
    'description': 'A unified cursor and construction plane for low-poly modeling',
    'category': 'Mesh',
}

import bpy
import bmesh
import blf
import gpu
from bpy.props import BoolProperty, FloatProperty, IntProperty, PointerProperty
from bpy_extras import view3d_utils as view
from gpu_extras.batch import batch_for_shader
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from .geometry import plane_basis, ray_plane, grid_snap, create_face, extrude, triangles, polygon_error

ACTIVE = set()
CYAN = (.15, .85, 1, 1)
GOLD = (1, .65, .15, 1)


class PigmiSettings(bpy.types.PropertyGroup):
    snap: BoolProperty(name='Vertex snapping', default=True)
    grid: BoolProperty(name='Grid snapping', default=False)
    step: FloatProperty(name='Grid step', default=.25, min=.001, subtype='DISTANCE')
    radius: IntProperty(name='Pick radius', default=12, min=4, max=40)


class PIGMI_OT_blank(bpy.types.Operator):
    bl_idname = 'pigmi.blank'
    bl_label = 'New Low-poly Mesh'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        mesh = bpy.data.meshes.new('Pigmi Mesh')
        obj = bpy.data.objects.new('Pigmi', mesh)
        context.collection.objects.link(obj)
        for other in context.selected_objects:
            other.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj
        obj.location = context.scene.cursor.location
        bpy.ops.object.mode_set(mode='EDIT')
        return {'FINISHED'}


class PIGMI_OT_model(bpy.types.Operator):
    bl_idname = 'pigmi.model'
    bl_label = 'Start Pigmi Modeler'
    bl_options = {'REGISTER', 'UNDO', 'BLOCKING'}

    @classmethod
    def poll(cls, context):
        return context.area and context.area.type == 'VIEW_3D' and context.mode == 'EDIT_MESH' and not ACTIVE

    def invoke(self, context, event):
        if len(context.objects_in_mode) != 1 or context.edit_object.data.shape_keys:
            self.report({'WARNING'}, 'Use one mesh without shape keys')
            return {'CANCELLED'}
        self.obj = context.edit_object
        if abs(self.obj.matrix_world.determinant()) < 1e-10:
            self.report({'WARNING'}, 'Object scale must be nonzero')
            return {'CANCELLED'}
        self.area = context.area
        self.region = next(r for r in self.area.regions if r.type == 'WINDOW')
        self.rv3d = context.space_data.region_3d
        self.settings = context.scene.pigmi_settings
        self.bm = bmesh.from_edit_mesh(self.obj.data)
        self.mouse = Vector((event.mouse_x - self.region.x, event.mouse_y - self.region.y))
        self.hover = None
        self.action = None
        self.points, self.refs = [], []
        self.cursor = None
        self.snap_ref = None
        self.plane_origin = context.scene.cursor.location.copy()
        self.plane_normal = self.rv3d.view_rotation @ Vector((0, 0, 1))
        self.plane_name = 'VIEW'
        self.history, self.future = [], []
        self.note = 'Hover, click or drag. F: draw a polygon.'
        self.rebuild()
        self.checkpoint()
        self.line_shader = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
        self.fill_shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        self.handlers = [
            bpy.types.SpaceView3D.draw_handler_add(self.draw_world, (), 'WINDOW', 'POST_VIEW'),
            bpy.types.SpaceView3D.draw_handler_add(self.draw_hud, (), 'WINDOW', 'POST_PIXEL'),
        ]
        ACTIVE.add(self)
        context.window_manager.modal_handler_add(self)
        self.area.tag_redraw()
        return {'RUNNING_MODAL'}

    def rebuild(self):
        for seq in (self.bm.verts, self.bm.edges, self.bm.faces):
            seq.ensure_lookup_table()
            seq.index_update()
        self.bm.normal_update()
        self.bvh = BVHTree.FromBMesh(self.bm) if self.bm.faces else None
        self.hover = None

    def checkpoint(self):
        mesh = bpy.data.meshes.new('.Pigmi history')
        copy = self.bm.copy()
        try:
            copy.to_mesh(mesh)
        finally:
            copy.free()
        self.history.append(mesh)
        for old in self.future:
            bpy.data.meshes.remove(old)
        self.future.clear()
        if len(self.history) > 33:
            bpy.data.meshes.remove(self.history.pop(0))

    def restore(self, mesh):
        self.bm.clear()
        self.bm.from_mesh(mesh)
        self.update()

    def update(self):
        bmesh.update_edit_mesh(self.obj.data, loop_triangles=True, destructive=True)
        self.rebuild()

    def ray(self, xy=None):
        xy = self.mouse if xy is None else xy
        return (view.region_2d_to_origin_3d(self.region, self.rv3d, xy),
                view.region_2d_to_vector_3d(self.region, self.rv3d, xy))

    def face_hit(self):
        if not self.bvh:
            return None
        origin, direction = self.ray()
        inv = self.obj.matrix_world.inverted()
        co, normal, index, distance = self.bvh.ray_cast(inv @ origin, (inv.to_3x3() @ direction).normalized())
        if index is not None:
            face = self.bm.faces[index]
            if not face.hide:
                return face, self.obj.matrix_world @ co
        return None

    def visible(self, point):
        if not self.bvh:
            return True
        xy = view.location_3d_to_region_2d(self.region, self.rv3d, point)
        if xy is None:
            return False
        origin, direction = self.ray(xy)
        inv = self.obj.matrix_world.inverted()
        target, local_origin = inv @ point, inv @ origin
        delta = target - local_origin
        if delta.length < 1e-7:
            return True
        hit, _, _, distance = self.bvh.ray_cast(local_origin, delta.normalized(), delta.length)
        return hit is None or (hit - target).length <= max(1e-4, delta.length * 1e-5)

    def pick(self):
        matrix = self.obj.matrix_world
        projected = {}
        candidates = []
        for vertex in self.bm.verts:
            if vertex.hide:
                continue
            point = matrix @ vertex.co
            xy = view.location_3d_to_region_2d(self.region, self.rv3d, point)
            projected[vertex] = xy
            if xy is not None and (xy - self.mouse).length <= self.settings.radius:
                candidates.append(((xy - self.mouse).length, vertex, point))
        for _, vertex, point in sorted(candidates, key=lambda x: x[0]):
            if self.visible(point):
                return vertex
        candidates = []
        for edge in self.bm.edges:
            if edge.hide:
                continue
            a, b = [projected.get(v) for v in edge.verts]
            if a is None or b is None:
                continue
            delta = b - a
            t = max(0, min(1, (self.mouse - a).dot(delta) / max(delta.length_squared, 1e-10)))
            distance = (self.mouse - a - t * delta).length
            if distance <= self.settings.radius * .8:
                point = matrix @ edge.verts[0].co.lerp(edge.verts[1].co, t)
                candidates.append((distance, edge, point))
        for _, edge, point in sorted(candidates, key=lambda x: x[0]):
            if self.visible(point):
                return edge
        hit = self.face_hit()
        return hit[0] if hit else None

    def point_on_plane(self, origin=None, normal=None, snap=True):
        origin = self.plane_origin if origin is None else origin
        normal = self.plane_normal if normal is None else normal
        point = ray_plane(*self.ray(), origin, normal)
        self.snap_ref = None
        if point is None:
            return None
        if snap and self.settings.snap:
            best = self.settings.radius
            for vertex in self.bm.verts:
                if vertex.hide or (self.action == 'MOVE' and vertex in self.moving):
                    continue
                target = self.obj.matrix_world @ vertex.co
                # Never silently break the construction plane to snap in depth.
                if abs((target - origin).dot(normal)) > 1e-5:
                    continue
                xy = view.location_3d_to_region_2d(self.region, self.rv3d, target)
                if xy is not None and (xy - self.mouse).length < best and self.visible(target):
                    best = (xy - self.mouse).length
                    point, self.snap_ref = target, vertex
        if self.snap_ref is None and snap and self.settings.grid:
            point = grid_snap(point, origin, normal, self.settings.step)
        return point

    def element_points(self, element):
        verts = [element] if isinstance(element, bmesh.types.BMVert) else element.verts
        return [self.obj.matrix_world @ v.co for v in verts]

    def select(self, element, extend=False):
        if not extend:
            for seq in (self.bm.faces, self.bm.edges, self.bm.verts):
                for item in seq:
                    item.select_set(False)
        element.select_set(not element.select if extend else True)
        bmesh.update_edit_mesh(self.obj.data, loop_triangles=False, destructive=False)

    def begin_move(self, element, event):
        if event.shift or not element.select:
            self.select(element, event.shift)
        if event.shift:
            return
        self.moving = [v for v in self.bm.verts if v.select and not v.hide]
        self.original = {v: v.co.copy() for v in self.moving}
        points = self.element_points(element)
        self.move_origin = sum(points, Vector()) / len(points)
        self.move_normal = self.rv3d.view_rotation @ Vector((0, 0, 1))
        self.anchor = self.point_on_plane(self.move_origin, self.move_normal, False)
        if self.anchor is None:
            return
        self.press_mouse = self.mouse.copy()
        self.action = 'MOVE'
        self.changed = False

    def cancel_action(self):
        if self.action == 'MOVE':
            for v, co in self.original.items():
                v.co = co
            self.update()
        self.action = None
        self.points, self.refs = [], []
        self.cursor, self.snap_ref = None, None

    def commit(self):
        self.update()
        self.checkpoint()
        self.action = None
        self.points, self.refs = [], []
        self.cursor, self.snap_ref = None, None

    def modal(self, context, event):
        try:
            return self.handle(context, event)
        except Exception as error:
            self.report({'ERROR'}, 'Pigmi: ' + str(error))
            # Restore the last committed state on unexpected errors.
            try:
                self.restore(self.history[-1])
            finally:
                self.finish()
            return {'FINISHED'}

    def handle(self, context, event):
        if context.mode != 'EDIT_MESH' or context.edit_object != self.obj:
            self.finish()
            return {'FINISHED'}
        self.area.tag_redraw()
        self.mouse = Vector((event.mouse_x - self.region.x, event.mouse_y - self.region.y))
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'TRACKPADPAN', 'TRACKPADZOOM', 'MOUSEROTATE'} or (event.alt and event.type in {'LEFTMOUSE', 'RIGHTMOUSE'}):
            return {'PASS_THROUGH'} if self.action != 'MOVE' else {'RUNNING_MODAL'}
        if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
            if self.action:
                self.cancel_action()
            else:
                self.finish()
                return {'FINISHED'}
            return {'RUNNING_MODAL'}
        if event.type == 'TAB' and event.value == 'PRESS':
            self.cancel_action()
            self.finish()
            return {'FINISHED'}
        if event.type == 'Z' and event.ctrl and event.value == 'PRESS':
            self.cancel_action()
            if event.shift and self.future:
                self.history.append(self.future.pop())
                self.restore(self.history[-1])
            elif not event.shift and len(self.history) > 1:
                self.future.append(self.history.pop())
                self.restore(self.history[-1])
            return {'RUNNING_MODAL'}
        inside = 0 <= self.mouse.x < self.region.width and 0 <= self.mouse.y < self.region.height
        if not inside and self.action != 'MOVE':
            return {'RUNNING_MODAL'}
        if event.type == 'MOUSEMOVE':
            if self.action == 'MOVE':
                if (self.mouse - self.press_mouse).length > 3:
                    point = self.point_on_plane(self.move_origin, self.move_normal)
                    if point is not None:
                        delta = point - self.anchor
                        # Snapping uses the element center as its anchor.
                        if self.snap_ref is not None:
                            delta = point - self.move_origin
                        elif self.settings.grid:
                            center = self.move_origin + delta
                            delta = grid_snap(center, self.move_origin, self.move_normal, self.settings.step) - self.move_origin
                        local_delta = self.obj.matrix_world.inverted().to_3x3() @ delta
                        for v, co in self.original.items():
                            v.co = co + local_delta
                        self.changed = True
                        bmesh.update_edit_mesh(self.obj.data, loop_triangles=True, destructive=False)
            elif self.action == 'DRAW':
                self.cursor = self.point_on_plane()
            elif self.action == 'EXTRUDE':
                if self.extrude_normal is not None:
                    units = (view.region_2d_to_location_3d(self.region, self.rv3d, self.start_mouse + Vector((0, 100)), self.extrude_origin) - view.region_2d_to_location_3d(self.region, self.rv3d, self.start_mouse, self.extrude_origin)).length / 100
                    amount = (self.mouse.y - self.start_mouse.y) * units
                    if self.settings.grid:
                        amount = round(amount / self.settings.step) * self.settings.step
                    self.delta = self.extrude_normal * amount
                else:
                    point = self.point_on_plane(self.extrude_origin, self.extrude_plane)
                    if point is not None:
                        self.delta = point - self.anchor
            else:
                self.hover = self.pick()
        if self.action == 'MOVE' and event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            if self.changed:
                self.commit()
            else:
                self.action = None
            return {'RUNNING_MODAL'}
        if event.value != 'PRESS':
            return {'RUNNING_MODAL'}
        if event.type == 'S' and not event.ctrl:
            self.settings.snap = not self.settings.snap
        elif event.type == 'G':
            self.settings.grid = not self.settings.grid
        elif self.action == 'DRAW':
            if event.type == 'BACK_SPACE' and self.points:
                self.points.pop()
                self.refs.pop()
            elif event.type == 'LEFTMOUSE':
                point = self.point_on_plane()
                if point is not None:
                    if self.points and (point - self.points[-1]).length < 1e-6:
                        return {'RUNNING_MODAL'}
                    self.points.append(point.copy())
                    self.refs.append(self.snap_ref)
            elif event.type in {'RET', 'NUMPAD_ENTER', 'SPACE'}:
                try:
                    create_face(self.bm, self.points, self.refs, self.obj.matrix_world, self.plane_normal)
                    self.commit()
                    self.note = 'Face created. F to draw another; E to grow an edge or face.'
                except ValueError as error:
                    self.note = str(error)
        elif self.action == 'EXTRUDE':
            if event.type in {'LEFTMOUSE', 'RET', 'NUMPAD_ENTER'}:
                try:
                    extrude(self.bm, self.source, self.obj.matrix_world.inverted().to_3x3() @ self.delta)
                    self.commit()
                except ValueError as error:
                    self.note = str(error)
        elif self.action is None:
            self.hover = self.pick()
            if event.type == 'LEFTMOUSE' and self.hover is not None:
                self.begin_move(self.hover, event)
            elif event.type == 'F':
                self.action = 'DRAW'
                self.cursor = self.point_on_plane()
                self.note = 'Click corners, Enter to build, Backspace to remove a corner.'
            elif event.type == 'V':
                self.plane_normal = self.rv3d.view_rotation @ Vector((0, 0, 1))
                if self.hover is not None:
                    points = self.element_points(self.hover)
                    self.plane_origin = sum(points, Vector()) / len(points)
                self.plane_name = 'VIEW'
                self.note = 'View plane captured. Orbit freely; V to capture again.'
            elif event.type == 'P':
                hit = self.face_hit()
                if hit:
                    face, _ = hit
                    self.plane_origin = self.obj.matrix_world @ face.calc_center_median()
                    self.plane_normal = (self.obj.matrix_world.to_3x3().inverted().transposed() @ face.normal).normalized()
                    self.plane_name = 'FACE'
                    self.note = 'Construction plane aligned to hovered face.'
            elif event.type in {'UP_ARROW', 'DOWN_ARROW'}:
                self.plane_origin += self.plane_normal * self.settings.step * (1 if event.type == 'UP_ARROW' else -1)
            elif event.type == 'E' and isinstance(self.hover, (bmesh.types.BMEdge, bmesh.types.BMFace)):
                if isinstance(self.hover, bmesh.types.BMEdge) and len(self.hover.link_faces) > 1:
                    self.note = 'Extrude a boundary edge, or hover a face.'
                    return {'RUNNING_MODAL'}
                self.source = self.hover
                self.source_points = self.element_points(self.source)
                self.extrude_origin = sum(self.source_points, Vector()) / len(self.source_points)
                self.start_mouse = self.mouse.copy()
                self.extrude_normal = ((self.obj.matrix_world.to_3x3().inverted().transposed() @ self.source.normal).normalized() if isinstance(self.source, bmesh.types.BMFace) else None)
                self.extrude_plane = self.rv3d.view_rotation @ Vector((0, 0, 1))
                self.anchor = self.point_on_plane(self.extrude_origin, self.extrude_plane, False)
                if self.anchor is not None:
                    self.delta = Vector()
                    self.action = 'EXTRUDE'
                    self.note = 'Move mouse, click to commit. Face depth: mouse up/down.'
            elif event.type == 'X' and self.hover is not None:
                kind = 'VERTS' if isinstance(self.hover, bmesh.types.BMVert) else 'EDGES' if isinstance(self.hover, bmesh.types.BMEdge) else 'FACES_ONLY'
                bmesh.ops.delete(self.bm, geom=[self.hover], context=kind)
                self.commit()
        return {'RUNNING_MODAL'}

    def lines(self, points, color=CYAN, width=2):
        if not points:
            return
        shader = self.line_shader
        shader.bind()
        shader.uniform_float('viewportSize', gpu.state.viewport_get()[2:])
        shader.uniform_float('lineWidth', width)
        shader.uniform_float('color', color)
        batch_for_shader(shader, 'LINES', {'pos': points}).draw(shader)

    def polygon(self, points, color=CYAN, close=True):
        if len(points) >= 3 and close:
            self.fill_shader.bind()
            self.fill_shader.uniform_float('color', (*color[:3], .18))
            batch_for_shader(self.fill_shader, 'TRIS', {'pos': triangles(points)}).draw(self.fill_shader)
        edges = [p for a, b in zip(points, points[1:]) for p in (a, b)]
        if close and len(points) > 2:
            edges.extend((points[-1], points[0]))
        self.lines(edges, color)

    def draw_world(self):
        if bpy.context.area != self.area or bpy.context.region != self.region:
            return
        gpu.state.blend_set('ALPHA')
        gpu.state.depth_test_set('LESS_EQUAL')
        gpu.state.depth_mask_set(False)
        try:
            u, v = plane_basis(self.plane_normal)
            size = self.settings.step * 8
            corners = [self.plane_origin + u * x * size + v * y * size for x, y in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
            self.lines([p for a, b in zip(corners, corners[1:] + corners[:1]) for p in (a, b)], (.2, .65, .8, .28), 1)
            self.lines([self.plane_origin - u * size, self.plane_origin + u * size, self.plane_origin - v * size, self.plane_origin + v * size], (.2, .65, .8, .28), 1)
            if self.hover is not None and self.hover.is_valid and self.action is None:
                pts = self.element_points(self.hover)
                # The hovered element has already passed the occlusion check.
                gpu.state.depth_test_set('NONE')
                if len(pts) == 1:
                    s = max(.002, self.rv3d.view_distance * .007)
                    right = self.rv3d.view_rotation @ Vector((s, 0, 0))
                    up = self.rv3d.view_rotation @ Vector((0, s, 0))
                    self.lines([pts[0] - right, pts[0] + right, pts[0] - up, pts[0] + up], GOLD, 3)
                else:
                    self.polygon(pts, GOLD)
            gpu.state.depth_test_set('NONE')
            if self.action == 'DRAW':
                pts = self.points + ([self.cursor] if self.cursor is not None else [])
                valid = not polygon_error(pts, self.plane_normal) if len(pts) >= 3 else True
                self.polygon(pts, CYAN if valid else (1, .2, .2, 1), close=valid)
            elif self.action == 'EXTRUDE':
                moved = [p + self.delta for p in self.source_points]
                self.polygon(moved, CYAN)
                self.lines([p for a, b in zip(self.source_points, moved) for p in (a, b)])
                source = self.source_points
                pairs = list(zip(source, source[1:]))
                if len(source) > 2:
                    pairs.append((source[-1], source[0]))
                for a, b in pairs:
                    self.polygon([a, b, b + self.delta, a + self.delta])
            if self.snap_ref is not None and self.snap_ref.is_valid:
                p = self.obj.matrix_world @ self.snap_ref.co
                s = max(.002, self.rv3d.view_distance * .009)
                u = self.rv3d.view_rotation @ Vector((s, 0, 0))
                v = self.rv3d.view_rotation @ Vector((0, s, 0))
                self.lines([p-u-v, p+u-v, p+u-v, p+u+v, p+u+v, p-u+v, p-u+v, p-u-v], (0.4, 1, .3, 1), 3)
        finally:
            gpu.state.depth_mask_set(True)
            gpu.state.depth_test_set('NONE')
            gpu.state.blend_set('NONE')

    def draw_hud(self):
        if bpy.context.area != self.area or bpy.context.region != self.region:
            return
        rows = [
            'PIGMI / ' + (self.action or 'SHAPE') + '   |   Plane: ' + self.plane_name,
            'Drag: move  |  F: polygon  |  E: extrude  |  X: delete',
            'V: view plane  |  P: face plane  |  Up/Down: offset plane',
            'S: snap ' + ('ON' if self.settings.snap else 'OFF') + '  |  G: grid ' + ('ON' if self.settings.grid else 'OFF') + '  |  Ctrl Z / Shift Ctrl Z: undo / redo',
            'Esc/RMB: cancel gesture or exit  |  ' + str(len(self.bm.faces)) + ' faces / ' + str(sum(max(0, len(f.verts)-2) for f in self.bm.faces)) + ' tris',
            self.note,
        ]
        for i, row in enumerate(rows):
            blf.position(0, 24, self.region.height - 66 - i * 21, 0)
            blf.size(0, 13 if i else 17)
            blf.color(0, *(CYAN if i == 0 else (.9, .94, 1, 1)))
            blf.draw(0, row)

    def finish(self):
        for handler in getattr(self, 'handlers', []):
            bpy.types.SpaceView3D.draw_handler_remove(handler, 'WINDOW')
        self.handlers = []
        for mesh in self.history + self.future:
            bpy.data.meshes.remove(mesh)
        self.history, self.future = [], []
        ACTIVE.discard(self)
        self.area.tag_redraw()

    def cancel(self, context):
        self.cancel_action()
        self.finish()


class PIGMI_PT_panel(bpy.types.Panel):
    bl_label = 'Pigmi Modeler'
    bl_idname = 'PIGMI_PT_panel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Pigmi'

    def draw(self, context):
        layout = self.layout
        layout.label(text='Build the silhouette. Grow the form.')
        layout.operator('pigmi.blank', icon='MESH_DATA')
        layout.operator('pigmi.model', icon='EDITMODE_HLT')
        settings = context.scene.pigmi_settings
        layout.prop(settings, 'snap')
        layout.prop(settings, 'grid')
        layout.prop(settings, 'step')
        layout.prop(settings, 'radius')
        layout.separator()
        layout.label(text='Edit Mode • Single mesh')
        layout.label(text='F: draw • E: extrude • Drag: move')
        layout.label(text='P: face plane • V: view plane')
        layout.label(text='Esc: cancel gesture / finish session')


CLASSES = (PigmiSettings, PIGMI_OT_blank, PIGMI_OT_model, PIGMI_PT_panel)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.pigmi_settings = PointerProperty(type=PigmiSettings)


def unregister():
    for operator in list(ACTIVE):
        operator.cancel_action()
        operator.finish()
    del bpy.types.Scene.pigmi_settings
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
